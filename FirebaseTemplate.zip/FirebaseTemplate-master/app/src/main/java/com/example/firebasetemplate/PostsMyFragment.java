package com.example.firebasetemplate;

public class PostsMyFragment extends PostsHomeFragment{
}
