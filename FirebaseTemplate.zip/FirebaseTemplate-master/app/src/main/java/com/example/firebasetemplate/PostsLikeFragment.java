package com.example.firebasetemplate;

public class PostsLikeFragment extends PostsHomeFragment{
}
